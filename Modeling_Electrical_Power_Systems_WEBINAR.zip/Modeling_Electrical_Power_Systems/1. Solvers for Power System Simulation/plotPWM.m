
%%

% Run testPWM.slx before running this. Make sure and set cf to the desired
% carrier frequency in Hz.

figure(1),plot(mod1.time,mod1.signals.values,carr1.time,carr1.signals.values,pwm1.time,pwm1.signals.values-2.2)
xlabel('Time (s)'),ylabel('magnitude (pu)'),legend('modulation','carrier','pulses')
