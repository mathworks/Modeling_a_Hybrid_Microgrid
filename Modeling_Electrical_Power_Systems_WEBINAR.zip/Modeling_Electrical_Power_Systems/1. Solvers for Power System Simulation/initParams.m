R = 5;
L = 1e-4;
Ts = 1;
C = 1e-3;
Vdc = 41e3;
cf = 300;
Ts_AC = 5e-5;