addpath(genpath(pwd))

load initData