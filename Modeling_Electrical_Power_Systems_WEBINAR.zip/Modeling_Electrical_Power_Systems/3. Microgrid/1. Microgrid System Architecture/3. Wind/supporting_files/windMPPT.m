

load turbineData.mat

h = figure(3);plot(rpm,powerCurves,'b'),grid
set(h,'Color','w')
axis([0 3500 0 1.4])

% loop through curves and find maximum point

idx = [];
rpmMax = [];
powerMax = [];
x = 0;

for l = 2:9

x = x + 1;

idx1 = find(powerCurves(:,l) == max(powerCurves(:,l)));

idx(x) = idx1(1);

rpmMax(x) = rpm(idx(x));
powerMax(x) = powerCurves(idx(x),l); 

end

text(rpm(7),powerCurves(7,2)+0.03,'5 m/s')
text(rpm(9),powerCurves(9,3)+0.03,'6 m/s')
text(rpm(11),powerCurves(11,4)+0.03,'7 m/s')
text(rpm(13),powerCurves(13,5)+0.03,'8 m/s')
text(rpm(15),powerCurves(15,6)+0.03,'9 m/s')
text(rpm(17),powerCurves(17,7)+0.03,'10 m/s')
text(rpm(19),powerCurves(19,8)+0.03,'11 m/s')
text(rpm(21),powerCurves(21,9)+0.03,'12 m/s')



hold on,plot(rpmMax,powerMax,'r')
xlabel('Turbine speed referred to generator side (RPM)')
ylabel('Power (pu)')

plot([50 150],[1.35 1.35],'b')
text(200,1.35,'Wind Power Curves','FontSize',8)

plot([50 150],[1.25 1.25],'r')
text(200,1.25,'Maximum Power Curve','FontSize',8)
