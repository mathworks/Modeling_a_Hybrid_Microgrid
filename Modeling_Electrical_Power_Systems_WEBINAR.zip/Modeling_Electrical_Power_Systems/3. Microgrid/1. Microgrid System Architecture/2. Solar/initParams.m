

time = linspace(0,10,1000)';
irr1 = zeros(1000,1);
irr1(1:50) = linspace(0,2e3,50);
irr1(51:end) = 2e3;
irradiance = repmat(irr1,1,25);
temperature = 30;

Ts_Control = 1e-3;
Ts_AC = 1e-4;
Ts_DC = 1e-3;
Ts = 1e-4;

Vgrid = 220;

Ts_8760 = 3600;

create8760SolarProfiles

load('solarPanelLUTs.mat')

powerTable = solarPanel(1).powerTable;

load('solarPanel1LUT.mat')