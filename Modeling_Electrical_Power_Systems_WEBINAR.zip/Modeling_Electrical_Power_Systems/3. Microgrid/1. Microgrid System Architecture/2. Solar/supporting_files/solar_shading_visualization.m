hf = figure(1);hold on;box on
hf.Color = 'w';
ha = gca;
ha.XTickLabel = '';
ha.YTickLabel = '';


% panels

xc = 0.1:0.2:0.9;
yc = 0.1:0.2:0.9;

sp = [
    0.1 0.9
    0.1 0.7
    0.1 0.5
    0.1 0.3
    0.1 0.1
    0.3 0.9
    0.3 0.7
    0.3 0.5
    0.3 0.3
    0.3 0.1
    0.5 0.9
    0.5 0.7
    0.5 0.5
    0.5 0.3
    0.5 0.1
    0.7 0.9
    0.7 0.7
    0.7 0.5
    0.7 0.3
    0.7 0.1
    0.9 0.9
    0.9 0.7
    0.9 0.5
    0.9 0.3
    0.9 0.1];
    

for ol = 1:25

    hp = patch;
    hp.XData = [-0.02;0.02;0.02;-0.02]+sp(ol,1);
    hp.YData = [-0.02;-0.02;0.02;0.02]+sp(ol,2);
    hp.FaceColor = [0 1 0];

end

axis([0 1 0 1])
axis('square')

% shade

angle = linspace(0,2*pi,100);

hs = patch;
hs1 = patch;

hs.XData = 0.3*cos(angle)-0.3;
hs.YData = 0.3*sin(angle)-0.3;
hs.FaceColor = [217 217 217]/255;
hs1.XData = 0.15*cos(angle)-0.3;
hs1.YData = 0.15*sin(angle)-0.3;
hs1.FaceColor = [217 217 217]/255;

time = linspace(0,10,1000)';

irr1 = zeros(1000,1);
% irr1(101:600) = linspace(0,2e3,500);
% irr1(601:end) = 2e3;
irr1(1:50) = linspace(0,2e3,50);
irr1(51:end) = 2e3;

irradiance = repmat(irr1,1,25);

shade = zeros(1000,25);

xt = linspace(-0.3,1.3,1000);
yt = 0.6*sin(2*xt);

pause

for l = 1:1000

hs.XData = 0.3*cos(angle) + xt(l);
hs.YData = 0.3*sin(angle) + yt(l);
hs1.XData = 0.15*cos(angle) + xt(l);
hs1.YData = 0.15*sin(angle) + yt(l);

% calculate distance to each panel and if distance is less than 0.3 then
% panel is in shade

idx = sqrt(sum((sp - [xt(l) yt(l)]).^2,2)) < 0.3;

shade(l,:) = ~idx;
%[idx(1:5) idx(6:10) idx(11:15) idx(16:20) idx(21:25)]

pause(0.01)

end