time = out.Ran.V.Time;

Vnom = 4160*sqrt(2/3);
Inom = 35;

% star-connected load

zz = zeros(332,1);

V_Ran = [zz;out.Ran.V.Data/Vnom];
V_Rbn = [zz;out.Rbn.V.Data/Vnom];
V_Rcn = [zz;out.Rcn.V.Data/Vnom];

Vmag_Ran = out.Ran.Vmag.Data/Vnom;
Vmag_Rbn = out.Rbn.Vmag.Data/Vnom;
Vmag_Rcn = out.Rcn.Vmag.Data/Vnom;

Vangle_Ran = out.Ran.Vangle.Data;
Vangle_Rbn = out.Rbn.Vangle.Data;
Vangle_Rcn = out.Rcn.Vangle.Data;

I_Ran = [zz;out.Ran.I.Data/Inom];
I_Rbn = [zz;out.Rbn.I.Data/Inom];
I_Rcn = [zz;out.Rcn.I.Data/Inom];
I_n = [zz;out.Iground.I.Data/Inom];

Imag_Ran = out.Ran.Imag.Data/Inom;
Imag_Rbn = out.Rbn.Imag.Data/Inom;
Imag_Rcn = out.Rcn.Imag.Data/Inom;
Imag_n = out.Iground.Imag.Data/Inom;

Iangle_Ran = out.Ran.Iangle.Data;
Iangle_Rbn = out.Rbn.Iangle.Data;
Iangle_Rcn = out.Rcn.Iangle.Data;
Iangle_n = out.Iground.Iangle.Data;

arrow_style = 'plain';

t = linspace(0,2*pi,100);

mm = 1;

nt = 333;

hf = figure(1);hp = plot(mm*cos(t)+2,mm*sin(t)-1,'k',cos(t)+2,sin(t)+2.5,'k',[-3.5 -0.5 -0.5 -3.5 -3.5],[0.5 0.5 2.5 2.5 0.5]+1,'k',[-3.5 -0.5 -0.5 -3.5 -3.5],[0.5 0.5 2.5 2.5 0.5]-2.5,'k',...
    linspace(-3.5,-0.5,nt),V_Ran((1:nt)+nt)/100+1.5,...
    linspace(-3.5,-0.5,nt),V_Rbn((1:nt)+nt)/100+1.5,...
    linspace(-3.5,-0.5,nt),V_Rcn((1:nt)+nt)/100+1.5,...
    linspace(-3.5,-0.5,nt),I_Ran((1:nt)+nt)/100-1.5,...
    linspace(-3.5,-0.5,nt),I_Rbn((1:nt)+nt)/100-1.5,...
    linspace(-3.5,-0.5,nt),I_Rcn((1:nt)+nt)/100,...
    linspace(-3.5,-0.5,nt),I_n((1:nt)+nt)/100-1,...
    [-3.5 -0.5],[2.5 2.5],'k',[-3.5 -0.5],[-1 -1],'k');
set(hf,'Position',[-1804.33       -271.00       1050.67        790.00])
axis([-4 4 -4 4]),axis('square')
ha = gca;
set(ha,'Visible','off')
set(hf,'Color','w')

set(hp(5),'LineWidth',5,'color',[255 165 0]/255)
set(hp(6),'LineWidth',5,'color',[0 158 115]/255)
set(hp(7),'LineWidth',5,'color',[97 100 252]/255)
set(hp(8),'LineWidth',5,'color',[255 165 0]/255)
set(hp(9),'LineWidth',5,'color',[0 158 115]/255)
set(hp(10),'LineWidth',5,'color',[97 100 252]/255)
set(hp(11),'LineWidth',5,'color','r')



h_V_Ran = annotation('arrow');
h_V_Rbn = annotation('arrow');
h_V_Rcn = annotation('arrow');

h_I_Ran = annotation('arrow');
h_I_Rbn = annotation('arrow');
h_I_Rcn = annotation('arrow');
h_I_n = annotation('arrow');

h_ref_VRan = annotation('line');
h_ref_VRbn = annotation('line');
h_ref_VRcn = annotation('line');

h_ref_IRan = annotation('line');
h_ref_IRbn = annotation('line');
h_ref_IRcn = annotation('line');
h_In = annotation('line');

h_VRan = annotation('line');
h_VRbn = annotation('line');
h_VRcn = annotation('line');

h_IRan = annotation('line');
h_IRbn = annotation('line');
h_IRcn = annotation('line');

text(-2.8,3.8,'Phase Voltage','FontSize',14)
text(-2.7,-2.5,'Line Current','Fontsize',14)

set(h_V_Ran,'Parent',ha,'Headstyle',arrow_style,'HeadWidth',15,'Linewidth',5,'Color',[255 165 0]/255);
set(h_V_Rbn,'Parent',ha,'Headstyle',arrow_style,'HeadWidth',15,'Linewidth',5,'Color',[0 158 115]/255);
set(h_V_Rcn,'Parent',ha,'Headstyle',arrow_style,'HeadWidth',15,'Linewidth',5,'Color',[97 100 252]/255);
set(h_ref_VRan,'Parent',ha,'Linewidth',1,'Color','k','LineStyle',':');
set(h_ref_VRbn,'Parent',ha,'Linewidth',1,'Color','k','LineStyle',':');
set(h_ref_VRcn,'Parent',ha,'Linewidth',1,'Color','k','LineStyle',':');
set(h_I_Ran,'Parent',ha,'Headstyle',arrow_style,'HeadWidth',15,'Linewidth',5,'Color',[255 165 0]/255);
set(h_I_Rbn,'Parent',ha,'Headstyle',arrow_style,'HeadWidth',15,'Linewidth',5,'Color',[0 158 115]/255);
set(h_I_Rcn,'Parent',ha,'Headstyle',arrow_style,'HeadWidth',15,'Linewidth',5,'Color',[97 100 252]/255);
set(h_I_n,'Parent',ha,'Headstyle',arrow_style,'HeadWidth',15,'Linewidth',5,'Color','r');


set(h_ref_IRan,'Parent',ha,'Linewidth',1,'Color','k','LineStyle',':');
set(h_ref_IRbn,'Parent',ha,'Linewidth',1,'Color','k','LineStyle',':');
set(h_ref_IRcn,'Parent',ha,'Linewidth',1,'Color','k','LineStyle',':');
set(h_In,'Parent',ha,'Linewidth',1,'Color','r','LineStyle',':');

set(h_VRan,'Parent',ha,'Linewidth',1,'Color',[255 165 0]/255,'LineStyle',':');
set(h_VRbn,'Parent',ha,'Linewidth',1,'Color',[0 158 115]/255,'LineStyle',':');
set(h_VRcn,'Parent',ha,'Linewidth',1,'Color',[97 100 252]/255,'LineStyle',':');

set(h_IRan,'Parent',ha,'Linewidth',1,'Color',[255 165 0]/255,'LineStyle',':');
set(h_IRbn,'Parent',ha,'Linewidth',1,'Color',[0 158 115]/255,'LineStyle',':');
set(h_IRcn,'Parent',ha,'Linewidth',1,'Color',[97 100 252]/255,'LineStyle',':');


h_A = annotation('line');
h_B = annotation('line');
h_C = annotation('line');

set(h_A,'Parent',ha,'Linewidth',5,'Color',[255 165 0]/255);
set(h_B,'Parent',ha,'Linewidth',5,'Color',[0 158 115]/255);
set(h_C,'Parent',ha,'Linewidth',5,'Color',[97 100 252]/255);

set(h_A,'X',[-3.5 -3.3],'Y',[1.1 1.1]);
set(h_B,'X',[-3.5 -3.3],'Y',[0.9 0.9]);
set(h_C,'X',[-3.5 -3.3],'Y',[0.7 0.7]);

text(-3.2,1.12,'Phase A','Fontsize',12)
text(-3.2,0.92,'Phase B','Fontsize',12)
text(-3.2,0.72,'Phase C','Fontsize',12)


htVa = text(-1.2*Vmag_Ran(end)*cos(-2*pi*60*time(end)-Vangle_Ran(end))+2,-1.2*Vmag_Ran(end)*sin(-2*pi*60*time(end)-Vangle_Ran(end))+2.5,'A','HorizontalAlignment','center');
htVb = text(-1.2*Vmag_Rbn(end)*cos(-2*pi*60*time(end)-Vangle_Rbn(end))+2,-1.2*Vmag_Rbn(end)*sin(-2*pi*60*time(end)-Vangle_Rbn(end))+2.5,'B','HorizontalAlignment','center');
htVc = text(-1.2*Vmag_Rcn(end)*cos(-2*pi*60*time(end)-Vangle_Rcn(end))+2,-1.2*Vmag_Rcn(end)*sin(-2*pi*60*time(end)-Vangle_Rcn(end))+2.5,'C','HorizontalAlignment','center');

htIa = text(-1.2*Imag_Ran(end)*cos(-2*pi*60*time(end)-Iangle_Ran(end))+2,-1.2*Imag_Ran(end)*sin(-2*pi*60*time(end)-Iangle_Ran(end))-1,'A','HorizontalAlignment','center');
htIb = text(-1.2*Imag_Rbn(end)*cos(-2*pi*60*time(end)-Iangle_Rbn(end))+2,-1.2*Imag_Rbn(end)*sin(-2*pi*60*time(end)-Iangle_Rbn(end))-1,'B','HorizontalAlignment','center');
htIc = text(-1.2*Imag_Rcn(end)*cos(-2*pi*60*time(end)-Iangle_Rcn(end))+2,-1.2*Imag_Rcn(end)*sin(-2*pi*60*time(end)-Iangle_Rcn(end))-1,'C','HorizontalAlignment','center');

for l = nt:numel(time)

    % star-connected load

    set(h_V_Ran,'X',[0 -Vmag_Ran(l)*cos(-2*pi*60*time(l)-Vangle_Ran(l))]+2,'Y',[0 -Vmag_Ran(l)*sin(-2*pi*60*time(l)-Vangle_Ran(l))]+2.5); % vectors
    
    set(h_V_Rbn,'X',[0 -Vmag_Rbn(l)*cos(-2*pi*60*time(l)-Vangle_Rbn(l))]+2,'Y',[0 -Vmag_Rbn(l)*sin(-2*pi*60*time(l)-Vangle_Rbn(l))]+2.5);
    
    set(h_V_Rcn,'X',[0 -Vmag_Rcn(l)*cos(-2*pi*60*time(l)-Vangle_Rcn(l))]+2,'Y',[0 -Vmag_Rcn(l)*sin(-2*pi*60*time(l)-Vangle_Rcn(l))]+2.5);
    
set(htVa,'Position',[-1.2*Vmag_Ran(l)*cos(-2*pi*60*time(l)-Vangle_Ran(l))+2 -1.2*Vmag_Ran(l)*sin(-2*pi*60*time(l)-Vangle_Ran(l))+2.5 0]);
set(htVb,'Position',[-1.2*Vmag_Rbn(l)*cos(-2*pi*60*time(l)-Vangle_Rbn(l))+2 -1.2*Vmag_Rbn(l)*sin(-2*pi*60*time(l)-Vangle_Rbn(l))+2.5 0]);
set(htVc,'Position',[-1.2*Vmag_Rcn(l)*cos(-2*pi*60*time(l)-Vangle_Rcn(l))+2 -1.2*Vmag_Rcn(l)*sin(-2*pi*60*time(l)-Vangle_Rcn(l))+2.5 0]);

set(htIa,'Position',[-1.2*Imag_Ran(l)*cos(-2*pi*60*time(l)-Iangle_Ran(l))+2 -1.2*Imag_Ran(l)*sin(-2*pi*60*time(l)-Iangle_Ran(l))-1 0]);
set(htIb,'Position',[-1.2*Imag_Rbn(l)*cos(-2*pi*60*time(l)-Iangle_Rbn(l))+2 -1.2*Imag_Rbn(l)*sin(-2*pi*60*time(l)-Iangle_Rbn(l))-1 0]);
set(htIc,'Position',[-1.2*Imag_Rcn(l)*cos(-2*pi*60*time(l)-Iangle_Rcn(l))+2 -1.2*Imag_Rcn(l)*sin(-2*pi*60*time(l)-Iangle_Rcn(l))-1 0]);

%     set(h_ref_VRan,'X',[0 -cos(-2*pi*60*time(l))]+2,'Y',[0 -sin(-2*pi*60*time(l))]+2.5);
%     
%     set(h_ref_VRbn,'X',[0 -cos(-2*pi*60*time(l)-2*pi/3)]+2,'Y',[0 -sin(-2*pi*60*time(l)-2*pi/3)]+2.5);
%     
%     set(h_ref_VRcn,'X',[0 -cos(-2*pi*60*time(l)+2*pi/3)]+2,'Y',[0 -sin(-2*pi*60*time(l)+2*pi/3)]+2.5);
%     
    set(h_VRan,'X',[-0.5 -Vmag_Ran(l)*cos(-2*pi*60*time(l)-Vangle_Ran(l))+2],'Y',[V_Ran(nt+l)+2.5 V_Ran(nt+l)+2.5]);
    set(h_VRbn,'X',[-0.5 -Vmag_Rbn(l)*cos(-2*pi*60*time(l)-Vangle_Rbn(l))+2],'Y',[V_Rbn(nt+l)+2.5 V_Rbn(nt+l)+2.5]);
    set(h_VRcn,'X',[-0.5 -Vmag_Rcn(l)*cos(-2*pi*60*time(l)-Vangle_Rcn(l))+2],'Y',[V_Rcn(nt+l)+2.5 V_Rcn(nt+l)+2.5]);
    
    set(hp(5),'YData',V_Ran((1:nt)+l)+2.5)
    set(hp(6),'YData',V_Rbn((1:nt)+l)+2.5)
    set(hp(7),'YData',V_Rcn((1:nt)+l)+2.5)
    set(hp(8),'YData',I_Ran((1:nt)+l)-1)
    set(hp(9),'YData',I_Rbn((1:nt)+l)-1)
    set(hp(10),'YData',I_Rcn((1:nt)+l)-1)
    set(hp(11),'YData',I_n((1:nt)+l)-1)


    % current

    set(h_I_Ran,'X',[0 -Imag_Ran(l)*cos(-2*pi*60*time(l)-Iangle_Ran(l))]+2,'Y',[0 -Imag_Ran(l)*sin(-2*pi*60*time(l)-Iangle_Ran(l))]-1); % vectors
    set(h_I_n,'X',[0 -Imag_n(l)*cos(-2*pi*60*time(l)-Iangle_n(l))]+2,'Y',[0 -Imag_n(l)*sin(-2*pi*60*time(l)-Iangle_n(l))]-1); % vectors
    
    xx1 = -Imag_Ran(l)*cos(-2*pi*60*time(l)-Iangle_Ran(l));
    yy1 = -Imag_Ran(l)*sin(-2*pi*60*time(l)-Iangle_Ran(l));

    set(h_I_Rbn,'X',[0 -Imag_Rbn(l)*cos(-2*pi*60*time(l)-Iangle_Rbn(l))]+2+xx1,'Y',[0 -Imag_Rbn(l)*sin(-2*pi*60*time(l)-Iangle_Rbn(l))]-1+yy1);
    
    xx2 = -Imag_Rbn(l)*cos(-2*pi*60*time(l)-Iangle_Rbn(l))+xx1;
    yy2 = -Imag_Rbn(l)*sin(-2*pi*60*time(l)-Iangle_Rbn(l))+yy1;

    set(h_I_Rcn,'X',[0 -Imag_Rcn(l)*cos(-2*pi*60*time(l)-Iangle_Rcn(l))]+2+xx2,'Y',[0 -Imag_Rcn(l)*sin(-2*pi*60*time(l)-Iangle_Rcn(l))]-1+yy2);

     set(h_ref_IRan,'X',[2 -Imag_Ran(l)*cos(-2*pi*60*time(l)-Iangle_Ran(l))+2],'Y',[-1 -Imag_Ran(l)*sin(-2*pi*60*time(l)-Iangle_Ran(l))-1]);
     
     set(h_ref_IRbn,'X',[2 -Imag_Rbn(l)*cos(-2*pi*60*time(l)-Iangle_Rbn(l))+2],'Y',[-1 -Imag_Rbn(l)*sin(-2*pi*60*time(l)-Iangle_Rbn(l))-1]);
     
     set(h_ref_IRcn,'X',[2 -Imag_Rcn(l)*cos(-2*pi*60*time(l)-Iangle_Rcn(l))+2],'Y',[-1 -Imag_Rcn(l)*sin(-2*pi*60*time(l)-Iangle_Rcn(l))-1]);

     set(h_IRan,'X',[-0.5 -Imag_Ran(l)*cos(-2*pi*60*time(l)-Iangle_Ran(l))+2],'Y',[I_Ran(nt+l)-1 I_Ran(nt+l)-1]);
     set(h_IRbn,'X',[-0.5 -Imag_Rbn(l)*cos(-2*pi*60*time(l)-Iangle_Rbn(l))+2],'Y',[I_Rbn(nt+l)-1 I_Rbn(nt+l)-1]);
     set(h_IRcn,'X',[-0.5 -Imag_Rcn(l)*cos(-2*pi*60*time(l)-Iangle_Rcn(l))+2],'Y',[I_Rcn(nt+l)-1 I_Rcn(nt+l)-1]);
     set(h_In,'X',[-0.5 -Imag_n(l)*cos(-2*pi*60*time(l)-Iangle_n(l))+2],'Y',[I_n(nt+l)-1 I_n(nt+l)-1]);
    
    drawnow

end
