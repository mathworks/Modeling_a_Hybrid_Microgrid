% time-stamps to extract data

ts = 1:4:120;
idxT = ismember(logsout{1}.Values.Time,ts);

% duty cycle

duty_cycle = logsout{1}.Values.Data(idxT);

% cell voltage

cell_voltage = logsout{5}.Values.Data(idxT);

% cell current

cell_current = logsout{3}.Values.Data(idxT);

% output power

output_power = logsout{2}.Values.Data(idxT);

% output voltage

output_voltage = logsout{6}.Values.Data(idxT);

% irradiance

irradiance = logsout{4}.Values.Data(idxT);
